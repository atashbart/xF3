      program FIT_NLO

c  Author:  Glen Cowan
c  Date:    13-OCT-1997

c  Program to fit a function d = alpha*(h**beta) to measurements of
c  impact distance d of a ball rolling down a ramp of height h.

c  Fitting done with the method of least squares.  The chi^2 minimization
c  is carried out with the MINUIT routines from the CERN program library.
c  Program must be linked with MINUIT and with FCN_GALILEO.

      implicit        NONE

c  local variables

      integer            n_dof

      double precision   chi2

c  variables for MINUIT

      integer            npar
      parameter          (npar = 13)

      character*10       chnam(npar)

      integer            ierr
      integer            ird
      integer            isav
      integer            istat
      integer            ivarbl
      integer            iwr,n,m
      integer            npari, nparx

      double precision   arglis (10)
      double precision   bnd1, bnd2
      double precision   deriv (npar)
      double precision   dpar (npar)
      double precision   fmin, fedm, errdef
      double precision   covmat (npar, npar)
      external           FCN
      double precision   par (npar)

c  common block for data 

      integer            max_points
      parameter          (max_points = 781)  ! must be same as in FCN
      integer            num_points
      
      DOUBLE PRECISION  x(max_points),Q(max_points),y(max_points)
      DOUBLE PRECISION dy(max_points)
	
	common            / data_block / num_points
	common            / num_points / x, Q, y, dy
	
	open(21,file='NLO-result.txt')
c  Initialize MINUIT

      ird = 5         ! unit number for input to Minuit (keyboard)
      iwr = 6         ! unit number for output from Minuit (screen)
      isav = 7        ! unit number for use of the SAVE command
      call MNINIT (ird, iwr, isav)

c  Set print level to -1 (no output except SHOW commands)

c      arglis(1) = -1.d0
c      call MNEXCM (FCN, 'SET PRIN', arglis, 1, ierr, 0)

c  Define parameters alpha and beta, give initial values and step sizes.

     	 
	call MNPARM (1,'aug1',-0.266d0,0.01d0,-0.3d0,-0.2d0,ierr)
       call MNPARM (2,'aug2',0.0466d0,0.001d0,0.03d0,0.08d0,ierr)  ! 0
       call MNPARM (3,'aug3',-0.0044d0,0.001d0,-0.006d0,-0.002d0,ierr)
       

       
      
       call MNPARM (4,'avu',0.183d0,0.001d0,0.1d0,0.29d0,ierr)
       call MNPARM (5,'bvu',5.349d0,0.001d0,5.0d0,5.9d0,ierr) 
       call MNPARM (6,'bvd',0.324d0,0.001d0,0.3d0,0.4d0,ierr) 

        call MNPARM (7,'LAN',0.3163d0,0.01d0,0.001d0,0.8d0,ierr)
      
	 call MNPARM (8,'aa',0.0d0,0.0d0,0.00d0,0.00d0,ierr)
	 call MNPARM (9,'bb',0.0d0,0.0d0,0.00d0,0.00d0,ierr)
	 call MNPARM (10,'cc',0.0d0,0.0d0,0.00d0,0.00d0,ierr)
	call MNPARM (11,'aaaa',0.0d0,0.0d0,0.00d0,0.00d0,ierr)
	 call MNPARM (12,'bbbb',0.0d0,0.0d0,0.00d0,0.00d0,ierr)
	 call MNPARM (13,'cccc',0.0d0,0.0d0,0.00d0,0.00d0,ierr)
c  Get input data by calling FCN with iflag=1

      arglis(1) = 1.d0
      call MNEXCM (FCN, 'CALL', arglis, 1, ierr, 0)

c  Minimize chi2 using SIMPLEX and MIGRAD 

      call MNEXCM (FCN, 'SIMPLEX', arglis, 0, ierr, 0)
      call MNEXCM (FCN, 'MIGRAD', arglis, 0, ierr, 0)

c  Compute covariance matrix with HESSE

      call MNEXCM (FCN, 'HESSE', arglis, 0, ierr, 0)

c  Check errors with MINOS

c      call MNEXCM (FCN, 'MINOS', arglis, 0, ierr, 0)

c  Get results of fit

      call MNSTAT (fmin, fedm, errdef, npari, nparx, istat)
      chi2 = fmin
      n_dof = num_points - npari

      call MNPOUT (1, chnam(1), par(1), dpar(1), bnd1, bnd2, ivarbl)
      call MNPOUT (2, chnam(2), par(2), dpar(2), bnd1, bnd2, ivarbl)
   	call MNPOUT (3, chnam(3), par(3), dpar(3), bnd1, bnd2, ivarbl)
 	call MNPOUT (4, chnam(4), par(4), dpar(4), bnd1, bnd2, ivarbl)
	call MNPOUT (5, chnam(5), par(5), dpar(5), bnd1, bnd2, ivarbl)
	call MNPOUT (6, chnam(6), par(6), dpar(6), bnd1, bnd2, ivarbl)
	call MNPOUT (7, chnam(7), par(7), dpar(7), bnd1, bnd2, ivarbl)
      call MNPOUT (8, chnam(8), par(8), dpar(8), bnd1, bnd2, ivarbl)
	call MNPOUT (9, chnam(9), par(9), dpar(9), bnd1, bnd2, ivarbl)
	call MNPOUT (10, chnam(10), par(10), dpar(10), bnd1, bnd2, ivarbl)
      call MNPOUT (11, chnam(11), par(11), dpar(11), bnd1, bnd2, ivarbl)
	call MNPOUT (12, chnam(12), par(12), dpar(12), bnd1, bnd2, ivarbl)
	call MNPOUT (13, chnam(13), par(13), dpar(13), bnd1, bnd2, ivarbl)	

      
		
	
      call MNEMAT (covmat, npar)

      WRITE (*,*)
       WRITE (*,*) 'Results of DPDF using Fracture Functions:'
       WRITE (*,*)

       WRITE (*,*) 'aug1       = ', par(1), ' +- ',  dpar(1)
       WRITE (*,*) 'aug2        = ', par(2), ' +- ',  dpar(2)
       WRITE (*,*) 'aug3        = ', par(3), ' +- ',  dpar(3)
      
       
       WRITE (*,*) 'avu        = ', par(4), ' +- ',  dpar(4)
       WRITE (*,*) 'bvu        = ', par(5), ' +- ',  dpar(5)
       WRITE (*,*) 'bvd        = ', par(6), ' +- ',  dpar(6)
      

       
       
	 WRITE (*,*) 'lan    = ', par(7), ' +- ',  dpar(7)
       WRITE (*,*) 'chi2          = ', chi2
       WRITE (*,*) 'n_dof         = ', n_dof
       WRITE (*,*) 'chi2/n_dof    = ', chi2/FLOAT(n_dof)

      
      

	WRITE (21,*) 'aug1       = ', par(1), ' +- ',  dpar(1)
       WRITE (21,*) 'aug2        = ', par(2), ' +- ',  dpar(2)
       WRITE (21,*) 'aug3        = ', par(3), ' +- ',  dpar(3)
      
       
       WRITE (21,*) 'avu        = ', par(4), ' +- ',  dpar(4)
       WRITE (21,*) 'bvu        = ', par(5), ' +- ',  dpar(5)
       WRITE (21,*) 'bvd        = ', par(6), ' +- ',  dpar(6)
       
       
       
       WRITE (21,*) '  lan  = ', par(7), ' +- ',  dpar(7)
	  WRITE (21,*) '  aa = ', par(8), ' +- ',  dpar(8)
	   WRITE (21,*) '  bb = ', par(9), ' +- ',  dpar(9)
	    WRITE (21,*) '  cc = ', par(10), ' +- ',  dpar(10)
	 WRITE (21,*) '  aaaa = ', par(11), ' +- ',  dpar(11)
	   WRITE (21,*) '  bbbb = ', par(12), ' +- ',  dpar(12)
	    WRITE (21,*) '  cccc = ', par(13), ' +- ',  dpar(13)
       
       WRITE (21,*) 'chi2          = ', chi2
       WRITE (21,*) 'n_dof         = ', n_dof
       WRITE (21,*) 'chi2/n_dof    = ', chi2/FLOAT(n_dof)

       do m = 1, npari
	   do n = m, npari
        WRITE (21,*) 'cov(m,n)=', m, n, covmat(m,n)
	   end do
       end do




      stop
      END


!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


      subroutine FCN (npar, grad, chi2, par, iflag, futil)

c  Author:  Glen Cowan
c  Date:    13-OCT-1997

c  Program to fit a function d = alpha*(h**beta) to measurements of
c  impact distance d of a ball rolling down a ramp of height h.

c  Input:  integer            npar         number of parameters to fit
c          double precision   par(npar)    parameter vector
c          integer            iflag        select what to do
c          double precision   futil        optional external function
c
c  Output: double precision   grad(npar)   gradient vector (not filled)
c          double precision   chi2         chi^2 to be minimized

      implicit        NONE

c  constants

      integer           max_points
      parameter         (max_points = 781)  ! same as in driver prog
c	parameter          (npar = 5)

c  arguments and common blocks

      integer           npar,iflag
      double precision  futil, chi2, par(*), grad(*)

      integer           num_points
      
      DOUBLE PRECISION  x(max_points),Q(max_points),y(max_points)
      DOUBLE PRECISION dy(max_points)
	
	common            / data_block / num_points
	common            / num_points / x, Q, y, dy

c  local variables

      character*80      infile
      character*80      line

      integer           i
      integer           ios
      integer           lun



	double precision  g



      double precision xf3,F2p,F2d,F2ns,
     -  aug1,aug2,aug3,
     -avu,bvu,bvd,Lan,aa,bb,cc,aaaa,bbbb,cccc
        double precision f,Q0,a,b,nmax		 !  definition of parameters

	nmax=9.0
 	
  	Q0=1.0
      a=3.0
	b=0.5
	F = 4
      
	
c     begin

      if ( iflag .eq. 1 ) then        ! read input data

        write (*, *) 'enter file name for input data'
        read (*, '(a80)') infile
        lun = 30
        open (unit=lun, file = infile,
     1  form = 'formatted', status = 'old')

        i = 0
        ios = 0
        do while ( ios .eq. 0 )
          read (lun, fmt = '(a80)', iostat = ios) line
          if (ios .eq. 0 .and. .not. line(1:1) .eq. '!') then
            i = i + 1
            read (line, *) x(i), Q(i), y(i), dy(i) 
          endif
        end do
        close (lun)
        num_points = i
	  write(*,*)i
      endif

      if ( iflag .eq. 2 ) then        ! calculate gradient vector

      endif

c  calculate chi2
	
	aug1  = par(1)
        aug2   = par(2)
        aug3   = par(3)
        

        
       
        avu  = par(4)
        bvu   = par(5)
       
        bvd  =  par(6)

	lan=par(7)
      aa=par(8)
	bb=par(9)
	cc=par(10)
	 aaaa=par(11)
	bbbb=par(12)
	cccc=par(13)

      chi2 = 0.



	
chi2 = 0.

	 do i= 1, num_points
	   if (i.LE.227)then
	       		           
	g=F2p(x(i),Q(i),a,b,nmax,Q0,LAN,F,aug1,aug2,aug3,avu,bvu,bvd)*
     -(1+aa*(x(i)**bb/(1-x(i))+cc)/Q(i))
	    chi2 = chi2 +(y(i) - g)**2. / (dy(i))**2.  


   	   if(i.eq.227) goto 41

	   else

ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc	                                                                                                                                                                     ! ************ IN THE NAME OF GOD ****************!

	   
	   if (i.LE.386)then
	   
	g=F2d(x(i),Q(i),a,b,nmax,Q0,LAN,F,aug1,aug2,aug3,avu,bvu,bvd)*
     -(1+aaaa*(x(i)**bbbb/(1-x(i))+cccc)/Q(i))
	    chi2 = chi2 +(y(i) - g)**2. / (dy(i))**2.  
 	   if(i.eq.386) goto 41

	   
	   else

	if (i.LE.551)then
	   
	 g=F2ns(x(i),Q(i),a,b,nmax,Q0,LAN,F,aug1,aug2,aug3,avu,bvu,bvd)
	   chi2 = chi2 +(y(i) - g)**2. / (dy(i))**2.    
     
 	   if(i.eq.551) goto 41
	else

	   if (i.LE.781)then
	  
	 g=xf3(x(i),Q(i),a,b,nmax,Q0,LAN,F,aug1,aug2,aug3,avu,bvu,bvd)

	     chi2 = chi2 + (y(i) - g)**2 / dy(i)**2
	      if(i.eq.781) goto 41

           else

	  endif
       endif
	   endif
	   endif
c	write(*,*)  chi2/(781.  - 7.)
           
41       chi2 = chi2 
      end do
      
	  
       if ( iflag .eq. 3 ) then        ! finish up
	
      endif
	
    
	  
	 
 
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc	                                                                                                                                                                     ! ************ IN THE NAME OF GOD ****************!
	

	    



	   write (*,*)  i  ,  chi2/(float(num_points) - npar ) 
      return
      END


	!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


	include 'evoloutionNLO2.f'
	include 'input2.f'
	include  'jacobi.f'
	include  'psifcts.f'
	include  'wilson.f'
	include  'SUB-minuit.f'
