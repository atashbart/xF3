      FUNCTION pqq0(s)
      IMPLICIT DOUBLE PRECISION (A-Z)
      EulerGamma=0.5772156649
	 pqq0=4 - (8*(1/(1 + s) + 1/(2 + s) + 
     -       2*(EulerGamma + PSI(1 + s))))/
     -   3.
	return
	end

	function pqq1(s,f)
	IMPLICIT DOUBLE PRECISION (A-Z) 
      EulerGamma=0.5772156649
	cf=4./3.
	ca=3.
	tf=f
	Pi=3.141592654
      pqq1=cf*tf*(-2/(3.*(1 + s)**2) - 2/(9.*(1 + s)) - 
     -     2/(3.*(2 + s)**2) + 22/(9.*(2 + s)) + 
     -     (20*(EulerGamma + Psi(1 + s)))/9. + 
     -     (4*dpsi(1 + s,1))/3.) + 
     -  cf**2*(-(1 + s)**(-3) - 5/(1 + s) - (2 + s)**(-3) + 
     -     2/(2 + s)**2 + 5/(2 + s) + 3*dpsi(1 + s,1) + 
     -     (2*(EulerGamma + 1/(1 + s) + Psi(1 + s) - 
     -          (1 + s)*dpsi(2 + s,1)))/(1 + s)**2 + 
     -     (2*(EulerGamma + 1/(2 + s) + Psi(2 + s) - 
     -          (2 + s)*dpsi(3 + s,1)))/(2 + s)**2 - 
     -     4*((EulerGamma + Psi(1 + s))*
     -         dpsi(1 + s,1) - dpsi(1 + s,2)/2.)) + 
     -  ca*cf*(-(1 + s)**(-3) + 5/(6.*(1 + s)**2) + 
     -     53/(18.*(1 + s)) + Pi**2/(6.*(1 + s)) - 
     -     (2 + s)**(-3) + 5/(6.*(2 + s)**2) - 
     -     187/(18.*(2 + s)) + Pi**2/(6.*(2 + s)) - 
     -     (67*(EulerGamma + Psi(1 + s)))/9. + 
     -     (Pi**2*(EulerGamma + Psi(1 + s)))/3. - 
     -     (11*dpsi(1 + s,1))/3. - dpsi(1 + s,2))
	return
	end

	function taQ(Q,f,lan)
	IMPLICIT DOUBLE PRECISION (A-Z)
	beta0=11.-2./3.*f
	beta1=102.-38./3.*f
	taQ=(beta1 + (beta1 - beta0**2*Log(lan**2) + 
     -       beta0**2*Log(Q))*Log(-Log(lan**2) + Log(Q)))/
     -  (beta0**3*(-Log(lan**2) + Log(Q)))
	return
	end

	function taQ0(Q0,f,lan)
	IMPLICIT DOUBLE PRECISION (A-Z)
	beta0=11.-2./3.*f
	beta1=102.-38./3.*f
	taQ0=(beta1 + (beta1 - beta0**2*Log(lan**2) + 
     -       beta0**2*Log(Q0))*Log(-Log(lan**2) + Log(Q0)))/
     -  (beta0**3*(-Log(lan**2) + Log(Q0)))
	return
	end

	function ta(Q,Q0,f,lan)
      IMPLICIT DOUBLE PRECISION (A-Z)
	ta=taQ(Q,f,lan)-taQ0(Q0,f,lan)
	return
	end

	function t2n(Q,Q0,f,lan)
	IMPLICIT DOUBLE PRECISION (A-Z)
	beta0=11.-2./3.*f
	beta1=102.-38./3.*f
      t2n=((-2*beta1**2)/(27.*(-Log(lan**2) + Log(Q))**3) + 
     -     (beta0**2*beta1)/(2.*(-Log(lan**2) + Log(Q))**2) - 
     -     beta0**4/(-Log(lan**2) + Log(Q)) + 
     -     (beta1*(-2*beta1 + 
     -          9*beta0**2*(-Log(lan**2) + Log(Q)))*
     -        Log(-Log(lan**2) + Log(Q)))/
     -      (9.*(-Log(lan**2) + Log(Q))**3) - 
     -     (beta1**2*Log(-Log(lan**2) + Log(Q))**2)/
     -      (3.*(-Log(lan**2) + Log(Q))**3))/beta0**6 - 
     -  ((-2*beta1**2)/(27.*(-Log(lan**2) + Log(Q0))**3) + 
     -     (beta0**2*beta1)/
     -      (2.*(-Log(lan**2) + Log(Q0))**2) - 
     -     beta0**4/(-Log(lan**2) + Log(Q0)) + 
     -     (beta1*(-2*beta1 + 
     -          9*beta0**2*(-Log(lan**2) + Log(Q0)))*
     -        Log(-Log(lan**2) + Log(Q0)))/
     -      (9.*(-Log(lan**2) + Log(Q0))**3) - 
     -     (beta1**2*Log(-Log(lan**2) + Log(Q0))**2)/
     -      (3.*(-Log(lan**2) + Log(Q0))**3))/beta0**6
	return
	end


	function mnslo(Q,Q0,f,lan,s)
      IMPLICIT DOUBLE PRECISION (A-Z)
      mnslo=exp(ta(Q,Q0,f,lan)*(pqq0(s)+
     -t2n(Q,Q0,f,lan)/ta(Q,Q0,f,lan)*pqq1(s,f)))
	return
	end


	function momxf3(Q,Q0,f,lan,s,aug1,aug2,aug3,avu,bvu,bvd)
      IMPLICIT DOUBLE PRECISION (A-Z)
	Pi=3.141592654
      momxf3=mnslo(Q,Q0,f,lan,s)*(
     -gu(aug1,aug2,aug3,avu,bvu,bvd,s)
     -+gd(aug1,aug2,aug3,avu,bvu,bvd,s))*
     -(1+ta(Q,Q0,f,lan)/(4.*Pi)* c3nlo(s))
	return
	end
	
      function momf2p(Q,Q0,f,lan,s,aug1,aug2,aug3,avu,bvu,bvd)
      IMPLICIT DOUBLE PRECISION (A-Z)
	Pi=3.141592654
      momf2p=mnslo(Q,Q0,f,lan,s)*(
     -4./9.*guf(aug1,aug2,aug3,avu,bvu,bvd,s)
     -+1./9.*gdf(aug1,aug2,aug3,avu,bvu,bvd,s))*
     -(1+ta(Q,Q0,f,lan)/(4.*Pi)* c2nlo(s))
	return
	end
	
      function momf2d(Q,Q0,f,lan,s,aug1,aug2,aug3,avu,bvu,bvd)
      IMPLICIT DOUBLE PRECISION (A-Z)
	Pi=3.141592654
      momf2d=mnslo(Q,Q0,f,lan,s)*(
     -5./18.*(guf(aug1,aug2,aug3,avu,bvu,bvd,s)
     -+gdf(aug1,aug2,aug3,avu,bvu,bvd,s)))*
     -(1+ta(Q,Q0,f,lan)/(4.*Pi)* c2nlo(s))
	return
	end
	
      function momf2ns(Q,Q0,f,lan,s,aug1,aug2,aug3,avu,bvu,bvd)
      IMPLICIT DOUBLE PRECISION (A-Z)
	Pi=3.141592654
      momf2ns=mnslo(Q,Q0,f,lan,s)*(
     -1./3.*(guf(aug1,aug2,aug3,avu,bvu,bvd,s)
     --gdf(aug1,aug2,aug3,avu,bvu,bvd,s))+2./3.
     -*(3.3134127284740645e8*
     -     Gamma(0.18682401890222378 + 1.*s)/
     -   Gamma(13.040579290820865 + 1.*s) - 
     -  (1.2655096657044568e13*
     -     Gamma(1.1868240189022239 + 1.*s))/
     -   Gamma(14.040579290820865 + 1.*s) + 
     -  (1.2659068211018037e13*
     -     Gamma(1.1869464534241143 + 1.*s))/
     -   Gamma(14.040701725342757 + 1.*s)))*
     -(1+ta(Q,Q0,f,lan)/(4.*Pi)* c2nlo(s))
	return
	end	
     
	 function momf2ptmc(Q,Q0,f,lan,s,aug1,aug2,aug3,avu,bvu,bvd)
      IMPLICIT DOUBLE PRECISION (A-Z)
	Pi=3.141592654
	mN=0.938
	momf2ptmc=momf2p(Q,Q0,f,lan,s,aug1,aug2,aug3,avu,bvu,bvd) + 
     -  (mN**2*(-1 + s)*s*
     - momf2p(Q,Q0,f,lan,s+2.,aug1,aug2,aug3,avu,bvu,bvd))/(Q*(2 + s))
     - + (mN**4*Gamma(3 + s)**2*
     - momf2p(Q,Q0,f,lan,s+4.,aug1,aug2,aug3,avu,bvu,bvd))/
     -   (2.*Q**2*Gamma(-1 + s)*
     -     Gamma(5 + s))
		return
	end	

	function momf2dtmc(Q,Q0,f,lan,s,aug1,aug2,aug3,avu,bvu,bvd)
      IMPLICIT DOUBLE PRECISION (A-Z)
	Pi=3.141592654
	mN=0.938
	momf2dtmc=momf2d(Q,Q0,f,lan,s,aug1,aug2,aug3,avu,bvu,bvd) + 
     -  (mN**2*(-1 + s)*s*
     -momf2d(Q,Q0,f,lan,s+2.,aug1,aug2,aug3,avu,bvu,bvd))/(Q*(2 + s))
     -+ (mN**4*Gamma(3 + s)**2*
     - momf2d(Q,Q0,f,lan,s+4.,aug1,aug2,aug3,avu,bvu,bvd))/
     -   (2.*Q**2*Gamma(-1 + s)*
     -     Gamma(5 + s))
		return
	end	

