      function c3nlo(s)
	IMPLICIT DOUBLE PRECISION (A-Z)
	EulerGamma=0.5772156649
	Pi=3.141592654
	
	c3nlo= (-4*(9 + (2*Pi**2)/3.))/3. - 
     -  8/(3.*(1 + s)**2) + 16/(3.*(1 + s)) - 
     -  8/(3.*(2 + s)**2) + 8/(3.*(2 + s)) + 
     -  4*(EulerGamma + psi(1 + s)) + 
     -  (8*(EulerGamma + psi(2 + s)))/
     -   (3.*(1 + s)) + 
     -  (8*(EulerGamma + psi(3 + s)))/
     -   (3.*(2 + s)) + 
     -  (4*(Pi**2 + 6*
     -        (EulerGamma + psi(1 + s))**2 - 
     -       6*dpsi(1+s,1)))/9. + 
     -  (16*dpsi(1+s,1))/3.
	return
	end
      function c2nlo(s)
	IMPLICIT DOUBLE PRECISION (A-Z)
	EulerGamma=0.5772156649
	Pi=3.141592654
	cf=4./3.
	c2nlo=cf*(-9 - (2*Pi**2)/3. - 2/(1 + s)**2 + 6/(1 + s) - 
     -    2/(2 + s)**2 + 4/(2 + s) + 
     -    3*(EulerGamma + psi(1 + s)) + 
     -    (2*(EulerGamma + psi(2 + s)))/(1 + s) + 
     -    (2*(EulerGamma + psi(3 + s)))/(2 + s) + 
     -    (Pi**2 + 6*(EulerGamma + psi(1 + s))**2 - 
     -       6*dpsi(1 + s,1))/3. + 4*dpsi(1 + s,1))
	 return
	end