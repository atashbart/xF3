

	


	

	FUNCTION gammln(xx)
      DOUBLE PRECISION gammln,xx
      INTEGER j
      DOUBLE PRECISION ser,stp,tmp,x,y,cof(6)
      SAVE cof,stp
      DATA cof,stp/76.18009172947146d0,-86.50532032941677d0,
     *24.01409824083091d0,-1.231739572450155d0,.1208650973866179d-2,
     *-.5395239384953d-5,2.5066282746310005d0/
      x=xx
      y=x
      tmp=x+5.5d0
      tmp=(x+0.5d0)*dlog(tmp)-tmp
      ser=1.000000000190015d0
      do 11 j=1,6
        y=y+1.d0
        ser=ser+cof(j)/y
11    continue
      gammln=tmp+dlog(stp*ser/x)
      return
      END
	


	
      Function Pochammer(a,n)
	external gammln
	DOUBLE PRECISION gammln,Pochammer,a,n
	Pochammer=dExp(gammln(a+n))/dExp(gammln(a))
	return
	end



	Function nk(k,a,b)
	external Pochammer,gammln
	DOUBLE PRECISION k,a,b,Pochammer,nk,gammln
	nk= dSqrt(((1. + a + b + 2.*k)*dexp(gammln(1. +a +b +k)))/
     -    (dexp(gammln(k+1.))*dexp(gammln(1. + a + k))*
     -      dexp(gammln(1. + b + k))))*Pochammer(1.+ b,k)
	return
	end

c==================================================================

	Function Hk(x,a,b,k)
	IMPLICIT DOUBLE PRECISION(A - Z)
	If (k.eq.0) then
	Hk0=1.
	Hk=Hk0
	elseIf (k.eq.1) then
	Hk1=1.-((2. + a + b)*x)/(1. + b)
	Hk=Hk1
	elseIf (k.eq.2) then
	Hk2=1.+((3. + a + b)*x*(-2.*(2. + b) + (4. + a + b)*x))/
     -   ((1. + b)*(2. + b))
	Hk=Hk2
	elseIf (k.eq.3) then
	Hk3=1. - ((4. + a + b)*x*
     -     (3.*(2. + b)*(3. + b) - 3.*(3. + b)*(5. + a + b)*x + 
     -       (5. + a + b)*(6. + a + b)*x**2.))/
     -   ((1. + b)*(2. + b)*(3. + b))

	Hk=Hk3
	elseif (k.eq.4) then
	Hk4=((1. + b)*(2. + b)*(3. + b)*(4. + b)*(-1. + x)**4. + 
     -    4.*(4. + a)*(2. + b)*(3. + b)*(4. + b)*(-1. + x)**3.*
     -     x + 6.*(3. + a)*(4. + a)*(3. + b)*(4. + b)*
     -     (-1. + x)**2.*x**2. + 
     -    4.*(2. + a)*(3. + a)*(4. + a)*(4. + b)*(-1. + x)*
     -     x**3. + (1. + a)*(2. + a)*(3. + a)*(4. + a)*x**4.)/
     -  ((1. + b)*(2. + b)*(3. + b)*(4. + b))
	Hk=Hk4
	elseif (k.eq.5) then
	Hk5= -(((1.+ b)*(2 + b)*(3. + b)*(4. + b)*(5. + b)*
     -       (-1. + x)**5. + 
     -      5.*(5. + a)*(2. + b)*(3. + b)*(4. + b)*(5. + b)*
     -       (-1. + x)**4.*x + 
     -      10.*(4. + a)*(5. + a)*(3. + b)*(4. + b)*(5. + b)*
     -       (-1. + x)**3.*x**2. + 
     -      10.*(3. + a)*(4. + a)*(5. + a)*(4. + b)*(5. + b)*
     -       (-1. + x)**2.*x**3. + 
     -      5.*(2. + a)*(3. + a)*(4. + a)*(5. + a)*(5. + b)*
     -       (-1. + x)*x**4. + 
     -      (1. + a)*(2. + a)*(3. + a)*(4. + a)*(5. + a)*x**5.)/
     -    ((1. + b)*(2. + b)*(3. + b)*(4. + b)*(5. + b)))

	Hk=Hk5
	elseIf (k.eq.6) then
	Hk6=((1. + b)*(2. + b)*(3. + b)*(4. + b)*(5. + b)*(6. + b)*
     -     (-1. + x)**6. + 
     -    6.*(6. + a)*(2. + b)*(3. + b)*(4. + b)*(5. + b)*
     -     (6. + b)*(-1. + x)**5.*x + 
     -    15.*(5. + a)*(6. + a)*(3. + b)*(4. + b)*(5. + b)*
     -     (6. + b)*(-1. + x)**4.*x**2. + 
     -    20.*(4. + a)*(5. + a)*(6. + a)*(4. + b)*(5. + b)*
     -     (6. + b)*(-1. + x)**3.*x**3. + 
     -    15.*(3. + a)*(4. + a)*(5. + a)*(6. + a)*(5. + b)*
     -     (6. + b)*(-1. + x)**2.*x**4. + 
     -    6.*(2. + a)*(3. + a)*(4. + a)*(5. + a)*(6. + a)*
     -     (6. + b)*(-1. + x)*x**5. + 
     -    (1. + a)*(2. + a)*(3. + a)*(4. + a)*(5. + a)*(6. + a)*
     -     x**6)/
     -  ((1. + b)*(2. + b)*(3. + b)*(4. + b)*(5. + b)*(6. + b))

	Hk=Hk6
	elseif (k.eq.7) then
	Hk7=-(((1. + b)*(2. + b)*(3. + b)*(4. + b)*(5. + b)*
     -       (6. + b)*(7. + b)*(-1. + x)**7. + 
     -      7.*(7. + a)*(2. + b)*(3. + b)*(4. + b)*(5. + b)*
     -       (6. + b)*(7. + b)*(-1. + x)**6.*x + 
     -      21.*(6. + a)*(7. + a)*(3. + b)*(4. + b)*(5. + b)*
     -       (6. + b)*(7. + b)*(-1. + x)**5.*x**2. + 
     -      35.*(5. + a)*(6. + a)*(7. + a)*(4. + b)*(5. + b)*
     -       (6. + b)*(7. + b)*(-1. + x)**4.*x**3. + 
     -      35.*(4. + a)*(5. + a)*(6. + a)*(7. + a)*(5. + b)*
     -       (6. + b)*(7. + b)*(-1. + x)**3.*x**4. + 
     -      21.*(3. + a)*(4. + a)*(5. + a)*(6.+ a)*(7. + a)*
     -       (6. + b)*(7. + b)*(-1. + x)**2.*x**5. + 
     -      7.*(2. + a)*(3. + a)*(4. + a)*(5. + a)*(6. + a)*
     -       (7. + a)*(7. + b)*(-1. + x)*x**6. + 
     -      (1. + a)*(2. + a)*(3. + a)*(4. + a)*(5. + a)*
     -       (6. + a)*(7. + a)*x**7.)/
     -    ((1. + b)*(2. + b)*(3. + b)*(4. + b)*(5. + b)*
     -      (6. + b)*(7. + b)))

	Hk=Hk7
	elseif (k.eq.8) then
	Hk8=((1. + b)*(2. + b)*(3. + b)*(4. + b)*(5. + b)*(6. + b)*
     -     (7. + b)*(8. + b)*(-1. + x)**8. + 
     -    8.*(8. + a)*(2. + b)*(3. + b)*(4. + b)*(5. + b)*
     -     (6. + b)*(7. + b)*(8. + b)*(-1. + x)**7.*x + 
     -    28.*(7. + a)*(8. + a)*(3. + b)*(4. + b)*(5. + b)*
     -     (6. + b)*(7. + b)*(8. + b)*(-1. + x)**6.*x**2. + 
     -    56.*(6. + a)*(7. + a)*(8. + a)*(4. + b)*(5. + b)*
     -     (6. + b)*(7. + b)*(8. + b)*(-1. + x)**5.*x**3. + 
     -    70.*(5. + a)*(6. + a)*(7. + a)*(8. + a)*(5. + b)*
     -     (6. + b)*(7. + b)*(8. + b)*(-1. + x)**4.*x**4. + 
     -    56.*(4. + a)*(5. + a)*(6. + a)*(7. + a)*(8. + a)*
     -     (6. + b)*(7. + b)*(8. + b)*(-1. + x)**3.*x**5. + 
     -    28.*(3. + a)*(4. + a)*(5. + a)*(6. + a)*(7. + a)*
     -     (8. + a)*(7. + b)*(8. + b)*(-1. + x)**2.*x**6. + 
     -    8.*(2. + a)*(3. + a)*(4. + a)*(5. + a)*(6. + a)*
     -     (7. + a)*(8. + a)*(8. + b)*(-1. + x)*x**7. + 
     -    (1. + a)*(2. + a)*(3. + a)*(4. + a)*(5. + a)*(6. + a)*
     -     (7. + a)*(8. + a)*x**8.)/
     -  ((1. + b)*(2.+ b)*(3. + b)*(4. + b)*(5. + b)*(6. + b)*
     -    (7. + b)*(8. + b))

	Hk=Hk8
	elseif (k.eq.9) then
	Hk9= -(((1. + b)*(2. + b)*(3. + b)*(4. + b)*(5. + b)*
     -       (6. + b)*(7. + b)*(8. + b)*(9. + b)*(-1. + x)**9.
     -       + 9.*(9. + a)*(2. + b)*(3. + b)*(4. + b)*(5. + b)*
     -       (6. + b)*(7. + b)*(8. + b)*(9. + b)*(-1. + x)**8.*x
     -        + 36.*(8. + a)*(9. + a)*(3. + b)*(4. + b)*
     -       (5. + b)*(6. + b)*(7. + b)*(8. + b)*(9. + b)*
     -       (-1. + x)**7.*x**2. + 
     -      84.*(7. + a)*(8. + a)*(9. + a)*(4. + b)*(5. + b)*
     -       (6. + b)*(7. + b)*(8. + b)*(9. + b)*(-1. + x)**6.*
     -       x**3. + 126.*(6. + a)*(7. + a)*(8. + a)*(9. + a)*
     -       (5. + b)*(6. + b)*(7. + b)*(8. + b)*(9. + b)*
     -       (-1. + x)**5.*x**4. + 
     -      126.*(5. + a)*(6. + a)*(7. + a)*(8. + a)*(9. + a)*
     -       (6. + b)*(7. + b)*(8. + b)*(9. + b)*(-1. + x)**4.*
     -       x**5. + 84.*(4. + a)*(5. + a)*(6. + a)*(7.+ a)*
     -       (8. + a)*(9. + a)*(7. + b)*(8. + b)*(9. + b)*
     -       (-1. + x)**3.*x**6. + 
     -      36.*(3. + a)*(4. + a)*(5. + a)*(6. + a)*(7. + a)*
     -       (8. + a)*(9. + a)*(8. + b)*(9. + b)*(-1. + x)**2.*
     -       x**7. + 9.*(2. + a)*(3. + a)*(4. + a)*(5. + a)*
     -       (6. + a)*(7. + a)*(8. + a)*(9. + a)*(9. + b)*
     -       (-1. + x)*x**8. + 
     -      (1. + a)*(2. + a)*(3. + a)*(4. + a)*(5. + a)*
     -       (6. + a)*(7. + a)*(8. + a)*(9. + a)*x**9.)/
     -    ((1. + b)*(2. + b)*(3. + b)*(4. + b)*(5. + b)*
     -      (6. + b)*(7. + b)*(8. + b)*(9. + b)))

	Hk=Hk9
      end if
      return
      end

c==================================================================

	Function teta(x,a,b,k)
	IMPLICIT DOUBLE PRECISION(A - Z)
	teta = Hk(x,a,b,k)*nk(k,a,b)
	return
	end

	function ck(j,a,b,k)
	IMPLICIT DOUBLE PRECISION(A - Z)
	ck=((-1)**j*nk(k,a,b)
     - *dexp(gammln(k+1.))*
     -    Pochammer(1. + a + b + k,j))/
     -  (dexp(gammln(j+1))*dexp(gammln(-j + k+1.))*
     -    Pochammer(1. + b,j))
	return
	end

	function akxf3(a,b,k,Q,Q0,LAN,F,aug1,aug2,aug3,avu,bvu,bvd)
      IMPLICIT DOUBLE PRECISION(A - Z)
	sum=0.
	do 100 j=0,k
	sum = sum + ck(j,a,b,k)*momxf3(Q,Q0,f,lan,j+1
     -,aug1,aug2,aug3,avu,bvu,bvd)

 100	continue
	akxf3=sum
	return
	end


	Function xf3(x,Q,a,b,nmax,Q0,LAN,F,aug1,aug2,aug3,avu,bvu,bvd)
	IMPLICIT DOUBLE PRECISION(A - Z)
	sum=0.
	do 100 k=0,nmax
	sum = sum + teta(x,a,b,k)*akxf3(a,b,k,Q,Q0,LAN,F
     -,aug1,aug2,aug3,avu,bvu,bvd)
 100	continue
	xf3 = ((1.-x)**a)*(x**b)*sum
	return
	end
	
	function akxf2p(a,b,k,Q,Q0,LAN,F,aug1,aug2,aug3,avu,bvu,bvd)
	      IMPLICIT DOUBLE PRECISION(A - Z)
		sum=0.
	do 100 j=0,k
		sum = sum + ck(j,a,b,k)*momf2ptmc(Q,Q0,f,lan,j+1
     -,aug1,aug2,aug3,avu,bvu,bvd)
100	continue
		akxf2p=sum
		return
		end

	
	
	Function F2p(x,Q,a,b,nmax,Q0,LAN,F,aug1,aug2,aug3,avu,bvu,bvd)
		IMPLICIT DOUBLE PRECISION(A - Z)
		sum=0.
		do 100 k=0,nmax
		sum = sum + teta(x,a,b,k)*akxf2p(a,b,k,Q,Q0,LAN,F
     -,aug1,aug2,aug3,avu,bvu,bvd)
100	continue
		F2p = ((1.-x)**a)*(x**b)*sum
		return
	end
	
	function akxf2d(a,b,k,Q,Q0,LAN,F,aug1,aug2,aug3,avu,bvu,bvd)
		      IMPLICIT DOUBLE PRECISION(A - Z)
			sum=0.
			do 100 j=0,k
			sum = sum + ck(j,a,b,k)*momf2dtmc(Q,Q0,f,lan,j+1
     -,aug1,aug2,aug3,avu,bvu,bvd)
		
100	continue
			akxf2d=sum
			return
			end
			
      Function F2d(x,Q,a,b,nmax,Q0,LAN,F,aug1,aug2,aug3,avu,bvu,bvd)
		IMPLICIT DOUBLE PRECISION(A - Z)
		sum=0.
		do 100 k=0,nmax
		sum = sum + teta(x,a,b,k)*akxf2d(a,b,k,Q,Q0,LAN,F
     -,aug1,aug2,aug3,avu,bvu,bvd)
100	continue
		F2d = ((1.-x)**a)*(x**b)*sum
		return
	end	
	
      function akxf2ns(a,b,k,Q,Q0,LAN,F,aug1,aug2,aug3,avu,bvu,bvd)
		      IMPLICIT DOUBLE PRECISION(A - Z)
			sum=0.
			do 100 j=0,k
			sum = sum + ck(j,a,b,k)*momf2ns(Q,Q0,f,lan,j+1
     -,aug1,aug2,aug3,avu,bvu,bvd)
		
100	continue
			akxf2ns=sum
			return
			end	
			
			
      Function F2ns(x,Q,a,b,nmax,Q0,LAN,F,aug1,aug2,aug3,avu,bvu,bvd)
		IMPLICIT DOUBLE PRECISION(A - Z)
		sum=0.
		do 100 k=0,nmax
		sum = sum + teta(x,a,b,k)*akxf2ns(a,b,k,Q,Q0,LAN,F
     -,aug1,aug2,aug3,avu,bvu,bvd)
100	continue
		F2ns = ((1.-x)**a)*(x**b)*sum
		return
	end				
			

      

	
	
	
