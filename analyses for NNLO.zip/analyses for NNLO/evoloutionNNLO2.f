      FUNCTION pqq0(s)
      IMPLICIT DOUBLE PRECISION (A-Z)
      EulerGamma=0.5772156649
	 pqq0=4 - (8*(1/(1 + s) + 1/(2 + s) + 
     -       2*(EulerGamma + PSI(1 + s))))/
     -   3.
	return
	end

	function pqq1(s,f)
	IMPLICIT DOUBLE PRECISION (A-Z) 
      EulerGamma=0.5772156649
	cf=4./3.
	ca=3.
	tf=f
	Pi=3.141592654
      pqq1=cf*tf*(-2/(3.*(1 + s)**2) - 2/(9.*(1 + s)) - 
     -     2/(3.*(2 + s)**2) + 22/(9.*(2 + s)) + 
     -     (20*(EulerGamma + Psi(1 + s)))/9. + 
     -     (4*dpsi(1 + s,1))/3.) + 
     -  cf**2*(-(1 + s)**(-3) - 5/(1 + s) - (2 + s)**(-3) + 
     -     2/(2 + s)**2 + 5/(2 + s) + 3*dpsi(1 + s,1) + 
     -     (2*(EulerGamma + 1/(1 + s) + Psi(1 + s) - 
     -          (1 + s)*dpsi(2 + s,1)))/(1 + s)**2 + 
     -     (2*(EulerGamma + 1/(2 + s) + Psi(2 + s) - 
     -          (2 + s)*dpsi(3 + s,1)))/(2 + s)**2 - 
     -     4*((EulerGamma + Psi(1 + s))*
     -         dpsi(1 + s,1) - dpsi(1 + s,2)/2.)) + 
     -  ca*cf*(-(1 + s)**(-3) + 5/(6.*(1 + s)**2) + 
     -     53/(18.*(1 + s)) + Pi**2/(6.*(1 + s)) - 
     -     (2 + s)**(-3) + 5/(6.*(2 + s)**2) - 
     -     187/(18.*(2 + s)) + Pi**2/(6.*(2 + s)) - 
     -     (67*(EulerGamma + Psi(1 + s)))/9. + 
     -     (Pi**2*(EulerGamma + Psi(1 + s)))/3. - 
     -     (11*dpsi(1 + s,1))/3. - dpsi(1 + s,2))
	return
	end



	function pqq2(s,f)
	IMPLICIT DOUBLE PRECISION (A-Z) 
      EulerGamma=0.5772156649
      zeta3=1.202056903
	Pi=3.141592654
	pqq2=1295.384 + 1024/(27.*(1 + s)**5) - 1600/(9.*(1 + s)**4) + 
     -  589.8/(1 + s)**3 - 1258/(1 + s)**2 + 1641.1/(1 + s) - 
     -  3135/(2 + s) + 243.6/(3 + s) - 522.1/(4 + s) + 
     -  1174.898*(psi(s) - psi(1 + s)) - 
     -  (714.1*(EulerGamma + psi(2 + s)))/(1 + s) + 
     -  (563.9*(EulerGamma + 1/(1 + s) + psi(1 + s) - 
     -       (1 + s)*dpsi(2+s,1)))/(1 + s)**2 + 
     -  f*(173.927 + 128/(9.*(1 + s)**4) - 5216/(81.*(1 + s)**3) + 
     -     152.6/(1 + s)**2 - 197/(1 + s) + 
     -     8.982000000000001/(2 + s)**4 + 381.1/(2 + s) + 
     -     72.94/(3 + s) + 44.79/(4 + s) - 
     -     183.187*(psi(s) - psi(1 + s)) + 
     -     (5120*(EulerGamma + psi(2 + s)))/(81.*(1 + s)) - 
     -     (56.66*(EulerGamma + 1/(1 + s) + psi(1 + s) - 
     -          (1 + s)*dpsi(2+s,1)))/(1 + s)**2) - 
     -  (256.8*(3 + 2*EulerGamma*(1 + s) + 
     -       2*EulerGamma*(1 + s)**2*psi(1 + s) - 
     -       (1 + s)*(-1 + 2*EulerGamma*(1 + s))*psi(1 + s) + 
     -       (1 + s)**3*psi(1 + s)**2*psi(2 + s) - 
     -       2*(1 + s)**3*psi(1 + s)*psi(2 + s)**2 + 
     -       (1 + s)**3*psi(2 + s)**3 - 
     -       2*(1 + s)**2*dpsi(1+s,1) + 
     -       (1 + s)**3*dpsi(2+s,2)))/(1 + s)**4 + 
     -  f**2*((-64*(psi(s) - psi(1 + s)))/81. + 
     -     (64*(-3.1875 + (5*Pi**2)/6. + 3/(2.*(1 + s)**3) - 
     -          11/(2.*(1 + s)**2) + 7/(1 + s) - 3/(2.*(2 + s)**3) + 
     -          11/(2.*(2 + s)**2) - 6/(2 + s) - 
     -          5*dpsi(2+s,1) - (3*dpsi(2+s,2))/2. - 
     -          3*zeta3))/81.)

	return
	end

	function taQ(Q,f,lan)
	IMPLICIT DOUBLE PRECISION (A-Z)
	beta0=11.-2./3.*f
	beta1=102.-38./3.*f
	beta2=2857./2.-5033./18.*f+325./54.*f**2.
	taQ=((beta1**2 - beta0*beta2 - 2*beta0**2*beta1*Log(lan**2)+ 
     -       2*beta0**2*beta1*Log(Q))/
     -     (2.*beta0**2*(-Log(lan**2) + Log(Q))**2) + 
     -    (beta0**2 + beta1/(-Log(lan**2) + Log(Q)))*
     -     Log(-Log(lan**2) + Log(Q)) - 
     -    (beta1**2*Log(-Log(lan**2) + Log(Q))**2)/
     -     (2.*beta0**2*(-Log(lan**2) + Log(Q))**2))/beta0**3
	return
	end

	function taQ0(Q0,f,lan)
	IMPLICIT DOUBLE PRECISION (A-Z)
	beta0=11.-2./3.*f
	beta1=102.-38./3.*f
	beta2=2857./2.-5033./18.*f+325./54.*f**2.
	taQ0=((beta1**2 - beta0*beta2 - 2*beta0**2*beta1*Log(lan**2) + 
     -       2*beta0**2*beta1*Log(Q0))/
     -     (2.*beta0**2*(-Log(lan**2) + Log(Q0))**2) + 
     -    (beta0**2 + beta1/(-Log(lan**2) + Log(Q0)))*
     -     Log(-Log(lan**2) + Log(Q0)) - 
     -    (beta1**2*Log(-Log(lan**2) + Log(Q0))**2)/
     -     (2.*beta0**2*(-Log(lan**2) + Log(Q0))**2))/beta0**3
	return
	end

	function ta(Q,Q0,f,lan)
      IMPLICIT DOUBLE PRECISION (A-Z)
	ta=taQ(Q,f,lan)-taQ0(Q0,f,lan)
	return
	end

	function t2n(Q,Q0,f,lan)
	IMPLICIT DOUBLE PRECISION (A-Z)
	beta0=11.-2./3.*f
	beta1=102.-38./3.*f
	beta2=2857./2.-5033./18.*f+325./54.*f**2.
      t2n=((-192*(789*beta1**4 - 1400*beta0*beta1**2*beta2 + 
     -          625*beta0**2*beta2**2))/beta0**4 + 
     -     (9375*(-9*beta1**3 + 8*beta0*beta1*beta2)*
     -        (-Log(lan**2) + Log(Q)))/beta0**2 + 
     -     400000*(beta1**2 - beta0*beta2)*
     -      (-Log(lan**2) + Log(Q))**2 + 
     -     300000*beta0**2*beta1*(-Log(lan**2) + Log(Q))**3 - 
     -     600000*beta0**4*(-Log(lan**2) + Log(Q))**4 + 
     -     (60*beta1*(-2624*beta1**3 + 2400*beta0*beta1*beta2 - 
     -          5625*beta0**2*beta1**2*(-Log(lan**2) + Log(Q)) + 
     -          5000*beta0**3*beta2*(-Log(lan**2) + Log(Q)) + 
     -          10000*beta0**6*(-Log(lan**2) + Log(Q))**3)*
     -        Log(-Log(lan**2) + Log(Q)))/beta0**4 - 
     -     (600*beta1**2*(-344*beta1**2 + 400*beta0*beta2 + 
     -          125*beta0**2*beta1*(-Log(lan**2) + Log(Q)) + 
     -          1000*beta0**4*(-Log(lan**2) + Log(Q))**2)*
     -        Log(-Log(lan**2) + Log(Q))**2)/beta0**4 + 
     -     (12000*beta1**3*
     -        (12*beta1 + 25*beta0**2*(-Log(lan**2) + Log(Q)))*
     -        Log(-Log(lan**2) + Log(Q))**3)/beta0**4 - 
     -     (120000*beta1**4*Log(-Log(lan**2) + Log(Q))**4)/beta0**4
     -     )/(600000.*beta0**6*(-Log(lan**2) + Log(Q))**5) - 
     -  ((-192*(789*beta1**4 - 1400*beta0*beta1**2*beta2 + 
     -          625*beta0**2*beta2**2))/beta0**4 + 
     -     (9375*(-9*beta1**3 + 8*beta0*beta1*beta2)*
     -        (-Log(lan**2) + Log(Q0)))/beta0**2 + 
     -     400000*(beta1**2 - beta0*beta2)*
     -      (-Log(lan**2) + Log(Q0))**2 + 
     -     300000*beta0**2*beta1*(-Log(lan**2) + Log(Q0))**3 - 
     -     600000*beta0**4*(-Log(lan**2) + Log(Q0))**4 + 
     -     (60*beta1*(-2624*beta1**3 + 2400*beta0*beta1*beta2 - 
     -          5625*beta0**2*beta1**2*(-Log(lan**2) + Log(Q0)) + 
     -          5000*beta0**3*beta2*(-Log(lan**2) + Log(Q0)) + 
     -          10000*beta0**6*(-Log(lan**2) + Log(Q0))**3)*
     -        Log(-Log(lan**2) + Log(Q0)))/beta0**4 - 
     -     (600*beta1**2*(-344*beta1**2 + 400*beta0*beta2 + 
     -          125*beta0**2*beta1*(-Log(lan**2) + Log(Q0)) + 
     -          1000*beta0**4*(-Log(lan**2) + Log(Q0))**2)*
     -        Log(-Log(lan**2) + Log(Q0))**2)/beta0**4 + 
     -     (12000*beta1**3*
     -        (12*beta1 + 25*beta0**2*(-Log(lan**2) + Log(Q0)))*
     -        Log(-Log(lan**2) + Log(Q0))**3)/beta0**4 - 
     -     (120000*beta1**4*Log(-Log(lan**2) + Log(Q0))**4)/
     -      beta0**4)/
     -   (600000.*beta0**6*(-Log(lan**2) + Log(Q0))**5)
	return
	end

	function t3n(Q,Q0,f,lan)
	IMPLICIT DOUBLE PRECISION (A-Z)
	beta0=11.-2./3.*f
	beta1=102.-38./3.*f
	beta2=2857./2.-5033./18.*f+325./54.*f**2.
      t3n=((21703*beta1**6 - 59040*beta0*beta1**4*beta2 + 
     -        53760*beta0**2*beta1**2*beta2**2 - 
     -        16384*beta0**3*beta2**3)/
     -      (131072.*beta0**6*(-Log(lan**2) + Log(Q))**8) + 
     -     (3*(3263*beta1**5 - 5586*beta0*beta1**3*beta2 + 
     -          2401*beta0**2*beta1*beta2**2))/
     -      (117649.*beta0**4*(-Log(lan**2) + Log(Q))**7) + 
     -     (-127*beta1**4 + 234*beta0*beta1**2*beta2 - 
     -        108*beta0**2*beta2**2)/
     -      (216.*beta0**2*(-Log(lan**2) + Log(Q))**6) + 
     -     (6*(-28*beta1**3 + 25*beta0*beta1*beta2))/
     -      (625.*(-Log(lan**2) + Log(Q))**5) + 
     -     (3*beta0**2*(beta1**2 - beta0*beta2))/
     -      (4.*(-Log(lan**2) + Log(Q))**4) + 
     -     (beta0**4*beta1)/(3.*(-Log(lan**2) + Log(Q))**3) - 
     -     beta0**6/(2.*(-Log(lan**2) + Log(Q))**2) + 
     -     (beta1*(100570987125*beta1**5 - 
     -          186961068000*beta0*beta1**3*beta2 + 
     -          87127488000*beta0**2*beta1*beta2**2 + 
     -          180430848000*beta0**2*beta1**4*
     -           (-Log(lan**2) + Log(Q)) - 
     -          308883456000*beta0**3*beta1**2*beta2*
     -           (-Log(lan**2) + Log(Q)) + 
     -          132765696000*beta0**4*beta2**2*
     -           (-Log(lan**2) + Log(Q)) - 
     -          163498496000*beta0**4*beta1**3*
     -           (-Log(lan**2) + Log(Q))**2 + 
     -          154893312000*beta0**5*beta1*beta2*
     -           (-Log(lan**2) + Log(Q))**2 - 
     -          416353222656*beta0**6*beta1**2*
     -           (-Log(lan**2) + Log(Q))**3 + 
     -          371743948800*beta0**7*beta2*
     -           (-Log(lan**2) + Log(Q))**3 + 
     -          309786624000*beta0**10*(-Log(lan**2) + Log(Q))**5)*
     -        Log(-Log(lan**2) + Log(Q)))/
     -      (3.09786624e11*beta0**6*(-Log(lan**2) + Log(Q))**8) - 
     -     (beta1**2*(148561875*beta1**4 - 
     -          432180000*beta0*beta1**2*beta2 + 
     -          276595200*beta0**2*beta2**2 - 
     -          397209600*beta0**2*beta1**3*
     -           (-Log(lan**2) + Log(Q)) + 
     -          361267200*beta0**3*beta1*beta2*
     -           (-Log(lan**2) + Log(Q)) - 
     -          1044915200*beta0**4*beta1**2*
     -           (-Log(lan**2) + Log(Q))**2 + 
     -          1106380800*beta0**5*beta2*
     -           (-Log(lan**2) + Log(Q))**2 + 
     -          265531392*beta0**6*beta1*
     -           (-Log(lan**2) + Log(Q))**3 + 
     -          1106380800*beta0**8*(-Log(lan**2) + Log(Q))**4)*
     -        Log(-Log(lan**2) + Log(Q))**2)/
     -      (7.375872e8*beta0**6*(-Log(lan**2) + Log(Q))**8) + 
     -     (beta1**3*(-1414875*beta1**3 + 
     -          1481760*beta0*beta1*beta2 - 
     -          1958400*beta0**2*beta1**2*
     -           (-Log(lan**2) + Log(Q)) + 
     -          2257920*beta0**3*beta2*(-Log(lan**2) + Log(Q)) + 
     -          2195200*beta0**4*beta1*
     -           (-Log(lan**2) + Log(Q))**2 + 
     -          3687936*beta0**6*(-Log(lan**2) + Log(Q))**3)*
     -        Log(-Log(lan**2) + Log(Q))**3)/
     -      (2.63424e6*beta0**6*(-Log(lan**2) + Log(Q))**8) - 
     -     (beta1**4*(-2205*beta1**2 + 4704*beta0*beta2 + 
     -          6912*beta0**2*beta1*(-Log(lan**2) + Log(Q)) + 
     -          12544*beta0**4*(-Log(lan**2) + Log(Q))**2)*
     -        Log(-Log(lan**2) + Log(Q))**4)/
     -      (12544.*beta0**6*(-Log(lan**2) + Log(Q))**8) + 
     -     (3*beta1**5*(21*beta1 + 
     -          32*beta0**2*(-Log(lan**2) + Log(Q)))*
     -        Log(-Log(lan**2) + Log(Q))**5)/
     -      (224.*beta0**6*(-Log(lan**2) + Log(Q))**8) - 
     -     (beta1**6*Log(-Log(lan**2) + Log(Q))**6)/
     -      (8.*beta0**6*(-Log(lan**2) + Log(Q))**8))/beta0**9 - 
     -  ((21703*beta1**6 - 59040*beta0*beta1**4*beta2 + 
     -        53760*beta0**2*beta1**2*beta2**2 - 
     -        16384*beta0**3*beta2**3)/
     -      (131072.*beta0**6*(-Log(lan**2) + Log(Q0))**8) + 
     -     (3*(3263*beta1**5 - 5586*beta0*beta1**3*beta2 + 
     -          2401*beta0**2*beta1*beta2**2))/
     -      (117649.*beta0**4*(-Log(lan**2) + Log(Q0))**7) + 
     -     (-127*beta1**4 + 234*beta0*beta1**2*beta2 - 
     -        108*beta0**2*beta2**2)/
     -      (216.*beta0**2*(-Log(lan**2) + Log(Q0))**6) + 
     -     (6*(-28*beta1**3 + 25*beta0*beta1*beta2))/
     -      (625.*(-Log(lan**2) + Log(Q0))**5) + 
     -     (3*beta0**2*(beta1**2 - beta0*beta2))/
     -      (4.*(-Log(lan**2) + Log(Q0))**4) + 
     -     (beta0**4*beta1)/(3.*(-Log(lan**2) + Log(Q0))**3) - 
     -     beta0**6/(2.*(-Log(lan**2) + Log(Q0))**2) + 
     -     (beta1*(100570987125*beta1**5 - 
     -          186961068000*beta0*beta1**3*beta2 + 
     -          87127488000*beta0**2*beta1*beta2**2 + 
     -          180430848000*beta0**2*beta1**4*
     -           (-Log(lan**2) + Log(Q0)) - 
     -          308883456000*beta0**3*beta1**2*beta2*
     -           (-Log(lan**2) + Log(Q0)) + 
     -          132765696000*beta0**4*beta2**2*
     -           (-Log(lan**2) + Log(Q0)) - 
     -          163498496000*beta0**4*beta1**3*
     -           (-Log(lan**2) + Log(Q0))**2 + 
     -          154893312000*beta0**5*beta1*beta2*
     -           (-Log(lan**2) + Log(Q0))**2 - 
     -          416353222656*beta0**6*beta1**2*
     -           (-Log(lan**2) + Log(Q0))**3 + 
     -          371743948800*beta0**7*beta2*
     -           (-Log(lan**2) + Log(Q0))**3 + 
     -          309786624000*beta0**10*(-Log(lan**2) + Log(Q0))**5)
     -         *Log(-Log(lan**2) + Log(Q0)))/
     -      (3.09786624e11*beta0**6*(-Log(lan**2) + Log(Q0))**8) - 
     -     (beta1**2*(148561875*beta1**4 - 
     -          432180000*beta0*beta1**2*beta2 + 
     -          276595200*beta0**2*beta2**2 - 
     -          397209600*beta0**2*beta1**3*
     -           (-Log(lan**2) + Log(Q0)) + 
     -          361267200*beta0**3*beta1*beta2*
     -           (-Log(lan**2) + Log(Q0)) - 
     -          1044915200*beta0**4*beta1**2*
     -           (-Log(lan**2) + Log(Q0))**2 + 
     -          1106380800*beta0**5*beta2*
     -           (-Log(lan**2) + Log(Q0))**2 + 
     -          265531392*beta0**6*beta1*
     -           (-Log(lan**2) + Log(Q0))**3 + 
     -          1106380800*beta0**8*(-Log(lan**2) + Log(Q0))**4)*
     -        Log(-Log(lan**2) + Log(Q0))**2)/
     -      (7.375872e8*beta0**6*(-Log(lan**2) + Log(Q0))**8) + 
     -     (beta1**3*(-1414875*beta1**3 + 
     -          1481760*beta0*beta1*beta2 - 
     -          1958400*beta0**2*beta1**2*
     -           (-Log(lan**2) + Log(Q0)) + 
     -          2257920*beta0**3*beta2*(-Log(lan**2) + Log(Q0)) + 
     -          2195200*beta0**4*beta1*
     -           (-Log(lan**2) + Log(Q0))**2 + 
     -          3687936*beta0**6*(-Log(lan**2) + Log(Q0))**3)*
     -        Log(-Log(lan**2) + Log(Q0))**3)/
     -      (2.63424e6*beta0**6*(-Log(lan**2) + Log(Q0))**8) - 
     -     (beta1**4*(-2205*beta1**2 + 4704*beta0*beta2 + 
     -          6912*beta0**2*beta1*(-Log(lan**2) + Log(Q0)) + 
     -          12544*beta0**4*(-Log(lan**2) + Log(Q0))**2)*
     -        Log(-Log(lan**2) + Log(Q0))**4)/
     -      (12544.*beta0**6*(-Log(lan**2) + Log(Q0))**8) + 
     -     (3*beta1**5*(21*beta1 + 
     -          32*beta0**2*(-Log(lan**2) + Log(Q0)))*
     -        Log(-Log(lan**2) + Log(Q0))**5)/
     -      (224.*beta0**6*(-Log(lan**2) + Log(Q0))**8) - 
     -     (beta1**6*Log(-Log(lan**2) + Log(Q0))**6)/
     -      (8.*beta0**6*(-Log(lan**2) + Log(Q0))**8))/beta0**9

	return
	end


	function mnslo(Q,Q0,f,lan,s)
      IMPLICIT DOUBLE PRECISION (A-Z)
      mnslo=exp(ta(Q,Q0,f,lan)*(pqq0(s)+
     -t2n(Q,Q0,f,lan)/ta(Q,Q0,f,lan)*pqq1(s,f)+
     -t3n(Q,Q0,f,lan)/ta(Q,Q0,f,lan)*pqq2(s,f)))
	return
	end


	function momxf3(Q,Q0,f,lan,s,aug1,aug2,aug3,avu,bvu,bvd)
      IMPLICIT DOUBLE PRECISION (A-Z)
	Pi=3.141592654
      momxf3=mnslo(Q,Q0,f,lan,s)*(gu(aug1,aug2,aug3,avu,bvu,bvd,s)
     -+gd(aug1,aug2,aug3,avu,bvu,bvd,s))*
     -(1+ta(Q,Q0,f,lan)/(4.*Pi)* c3nlo(s)+
     -(ta(Q,Q0,f,lan)/(4.*Pi))**2.*c3nnlo(s,f))
	return
	end
     

	 function momf2p(Q,Q0,f,lan,s,aug1,aug2,aug3,avu,bvu,bvd)
      IMPLICIT DOUBLE PRECISION (A-Z)
	Pi=3.141592654
      momf2p=mnslo(Q,Q0,f,lan,s)*(
     -4./9.*guf(aug1,aug2,aug3,avu,bvu,bvd,s)
     -+1./9.*gdf(aug1,aug2,aug3,avu,bvu,bvd,s))*
     -(1+ta(Q,Q0,f,lan)/(4.*Pi)* c2nlo(s)+
     -(ta(Q,Q0,f,lan)/(4.*Pi))**2.*c2nnlo(s,f))
	return
	end
	
      function momf2d(Q,Q0,f,lan,s,aug1,aug2,aug3,avu,bvu,bvd)
      IMPLICIT DOUBLE PRECISION (A-Z)
	Pi=3.141592654
      momf2d=mnslo(Q,Q0,f,lan,s)*(
     -5./18.*(guf(aug1,aug2,aug3,avu,bvu,bvd,s)
     -+gdf(aug1,aug2,aug3,avu,bvu,bvd,s)))*
     -(1+ta(Q,Q0,f,lan)/(4.*Pi)* c2nlo(s)+(ta(Q,Q0,f,lan)/(4.*Pi))**2.
     -*c2nnlo(s,f))
	return
	end
	
      DOUBLE PRECISION FUNCTION MOMF2NS(Q,Q0,F,LAN,S,
     1                                  AUG1,AUG2,AUG3,AVU,
     2                                  BVU,BVD)
      IMPLICIT DOUBLE PRECISION (A-Z)
      DOUBLE PRECISION GUF,GDF,MNSLO,TA,C2NLO,C2NNLO,MomnSLO
      DOUBLE PRECISION FACTOR,CORRECTION,PI,MomnSLOo

      PI=3.141592653589793D0

      FACTOR=1.D0/3.D0
      MomnSLOo=((GUF(AUG1,AUG2,AUG3,AVU,BVU,BVD,S)
     2 -GDF(AUG1,AUG2,AUG3,AVU,BVU,BVD,S))
     3 +2.D0*
     4 (4.278997640882441D8*
     5  GAMMA(0.18857904675608994D0+S)/
     6  GAMMA(13.143885800260385D0+S)
     7 -1.7130348537379184D13*
     8  GAMMA(1.18857904675609D0+S)/
     9  GAMMA(14.143885800260385D0+S)
     1 +1.7135729715998398D13*
     2  GAMMA(1.188704548089627D0+S)/
     3  GAMMA(14.144011301593922D0+S)))*mnslo(Q,Q0,f,lan,s)

      CORRECTION=1.D0+TA(Q,Q0,F,LAN)/(4.D0*PI)*
     1 C2NLO(S)-(TA(Q,Q0,F,LAN)/(4.D0*PI))**2*
     2 C2NNLO(S,F)

      MOMF2NS=MomnSLOo* FACTOR*
     1 CORRECTION

      RETURN
      END


     
	 function momf2ptmc(Q,Q0,f,lan,s,aug1,aug2,aug3,avu,bvu,bvd)
      IMPLICIT DOUBLE PRECISION (A-Z)
	Pi=3.141592654
	mN=0.938
	momf2ptmc=momf2p(Q,Q0,f,lan,s,aug1,aug2,aug3,avu,bvu,bvd) + 
     -  (mN**2*(-1 + s)*s*
     - momf2p(Q,Q0,f,lan,s+2.,aug1,aug2,aug3,avu,bvu,bvd))/(Q*(2 + s))
     - + (mN**4*Gamma(3 + s)**2*
     - momf2p(Q,Q0,f,lan,s+4.,aug1,aug2,aug3,avu,bvu,bvd))/
     -   (2.*Q**2*Gamma(-1 + s)*
     -     Gamma(5 + s))
		return
	end	

	function momf2dtmc(Q,Q0,f,lan,s,aug1,aug2,aug3,avu,bvu,bvd)
      IMPLICIT DOUBLE PRECISION (A-Z)
	Pi=3.141592654
	mN=0.938
	momf2dtmc=momf2d(Q,Q0,f,lan,s,aug1,aug2,aug3,avu,bvu,bvd) + 
     -  (mN**2*(-1 + s)*s*
     -momf2d(Q,Q0,f,lan,s+2.,aug1,aug2,aug3,avu,bvu,bvd))/(Q*(2 + s))
     -+ (mN**4*Gamma(3 + s)**2*
     - momf2d(Q,Q0,f,lan,s+4.,aug1,aug2,aug3,avu,bvu,bvd))/
     -   (2.*Q**2*Gamma(-1 + s)*
     -     Gamma(5 + s))
		return
	end	

