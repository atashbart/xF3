      function c3nlo(s)
	IMPLICIT DOUBLE PRECISION (A-Z)
	EulerGamma=0.5772156649
	Pi=3.141592654
	cf=4./3.
	c3nlo=(-4*(9 + (2*Pi**2)/3.))/3. - 
     -  8/(3.*(1 + s)**2) + 16/(3.*(1 + s)) - 
     -  8/(3.*(2 + s)**2) + 8/(3.*(2 + s)) + 
     -  4*(EulerGamma + psi(1 + s)) + 
     -  (8*(EulerGamma + psi(2 + s)))/
     -   (3.*(1 + s)) + 
     -  (8*(EulerGamma + psi(3 + s)))/
     -   (3.*(2 + s)) + 
     -  (4*(Pi**2 + 6*
     -        (EulerGamma + psi(1 + s))**2 - 
     -       6*dpsi(1+s,1)))/9. + 
     -  (16*dpsi(1+s,1))/3.
	return
	end



	function c3nnlo(s,f)
      IMPLICIT DOUBLE PRECISION (A-Z)
	EulerGamma=0.5772156649
	Pi=3.141592654
	zeta3=1.202056903
	c3nnlo=-338.635-188.64/s+23.532/(1 + s)**4-66.62/(1 + s)**3+ 
     -  67.6/(1 + s)**2 - 206.1/(1 + s) - 576.8/(2 + s) - 
     -  (31.105*(EulerGamma + psi(1 + s)))/s + 
     -  (409.6*(EulerGamma + psi(2 + s)))/(1 + s) + 
     -  (10.2222*(Pi**2 + 6*(EulerGamma + psi(1 + s))**2 - 
     -       6*dpsi(1+s,1)))/s + 
     -  (94.61*(Pi**2 + 6*(EulerGamma + psi(2 + s))**2 - 
     -       6*dpsi(2+s,1)))/(6 + 6*s) + 
     -  (24.65*(6*EulerGamma**2 + Pi**2 + (12*EulerGamma)/(1 + s)+ 
     -       12*EulerGamma*psi(1 + s) - 
     -       6*(1 + s)*psi(1 + s)*psi(2 + s)**2 + 
     -       6*(1 + s)*psi(2 + s)**3 - 
     -       6*(3 + 2*EulerGamma*(1 + s))*dpsi(2+s,1) - 
     -       12*(1 + s)*psi(1 + s)*dpsi(2+s,1) + 
     -       6*(1 + s)*dpsi(2+s,2)))/(1 + s)**2 + 
     -  (7.1111*(2*EulerGamma**3 + EulerGamma*Pi**2 + 
     -       6*EulerGamma*psi(1 + s)**2 + 
     -       2*psi(1 + s)**3 + 
     -       psi(1 + s)*
     -        (6*EulerGamma**2 + Pi**2 - 6*dpsi(1+s,1)) - 
     -       6*EulerGamma*dpsi(1+s,1) + 2*dpsi(1+s,2) + 
     -       4*zeta3))/s + 
     -  (7.6*(2*EulerGamma**3 + EulerGamma*Pi**2 + 
     -       6*EulerGamma*psi(2 + s)**2 + 
     -       2*psi(2 + s)**3 + 
     -       psi(2 + s)*
     -        (6*EulerGamma**2 + Pi**2 - 6*dpsi(2+s,1)) - 
     -       6*EulerGamma*dpsi(2+s,1) + 2*dpsi(2+s,2) + 
     -       4*zeta3))/(1 + s) + 
     -  f*(46.857 - 6.3489/s + 4.414/(1 + s)**3 - 8.683/(1 + s)**2- 
     -     6.337/(1 + s) - 14.97/(2 + s) - 
     -     (8.5926*(EulerGamma + psi(1 + s)))/s - 
     -     (25*(EulerGamma + psi(2 + s)))/(1 + s) - 
     -     (0.29629*(Pi**2 + 6*(EulerGamma + psi(1 + s))**2 - 
     -          6*dpsi(1+s,1)))/s - 
     -     (0.808*(Pi**2 + 6*(EulerGamma + psi(2 + s))**2 - 
     -          6*dpsi(2+s,1)))/(6 + 6*s) + 
     -     (9.684*(EulerGamma + 1/(1 + s) + psi(1 + s) - 
     -          (1 + s)*dpsi(2+s,1)))/(1 + s)**2 - 
     -     (0.021*(2*EulerGamma**3 + EulerGamma*Pi**2 + 
     -          6*EulerGamma*psi(2 + s)**2 + 
     -          2*psi(2 + s)**3 + 
     -          psi(2 + s)*
     -           (6*EulerGamma**2 + Pi**2 - 6*dpsi(2+s,1)) - 
     -          6*EulerGamma*dpsi(2+s,1) + 
     -          2*dpsi(2+s,2) + 4*zeta3))/(1 + s))
	return
	end



	Function c2nnlo(s,f)
	 IMPLICIT DOUBLE PRECISION (A-Z)
	EulerGamma=0.5772156649
	Pi=3.141592654
	zeta3=1.202056903
	c2nnlo=-338.046 + 
     -  8613/(100.*(1 + s)**4) + 
     -  561/(125.*(1 + s)**3) + 
     -  f*(-63489/(10000.*s) + 
     -     (42963*
     -        (-EulerGamma - 
     -          psi(1 + s)))/
     -      (5000.*s) - 
     -     (88889*
     -        (Pi**2/6. + 
     -          (EulerGamma + 
     -             psi(1 + s))**2
     -           - dpsi(1 + s,1)))/
     -      (50000.*s)) + 
     -  (759*((2*
     -          (-EulerGamma - 
     -            psi(2 + s)))/
     -        (1 + s)**3 + 
     -       (2*dpsi(2 + s,1))/
     -        (1 + s)**2 - 
     -       dpsi(2 + s,2)/(1 + s)))/
     -   125. - (71111*
     -     (-(EulerGamma + 
     -           psi(1 + s))**3 - 
     -       3*(EulerGamma + 
     -          psi(1 + s))*
     -        (Pi**2/6. - 
     -          dpsi(1 + s,1)) - 
     -       dpsi(1 + s,2) - 
     -       2*Zeta3))/(5000.*s)
	return
	end

	 function c2nlo(s)
	IMPLICIT DOUBLE PRECISION (A-Z)
	EulerGamma=0.5772156649
	Pi=3.141592654
	cf=4./3.
	c2nlo=cf*(-9 - (2*Pi**2)/3. - 2/(1 + s)**2 + 6/(1 + s) - 
     -    2/(2 + s)**2 + 4/(2 + s) + 
     -    3*(EulerGamma + psi(1 + s)) + 
     -    (2*(EulerGamma + psi(2 + s)))/(1 + s) + 
     -    (2*(EulerGamma + psi(3 + s)))/(2 + s) + 
     -    (Pi**2 + 6*(EulerGamma + psi(1 + s))**2 - 
     -       6*dpsi(1 + s,1))/3. + 4*dpsi(1 + s,1))
	 return
	end